package com.scriptsbundle.nokri.RichEditor.styles.windows;

public interface FontSizeChangeListener {
    void onFontSizeChange(int fontSize);
}