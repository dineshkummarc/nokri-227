package com.scriptsbundle.nokri.activities.WPML;

public interface WPMLInterface {
    public void onLanguageSelected(LangArray langArray);
}
