package com.scriptsbundle.nokri.RichEditor.spans;

import android.text.style.SubscriptSpan;

/**
 * Created by wliu on 2018/4/3.
 */

public class AreSubscriptSpan extends SubscriptSpan {
}
