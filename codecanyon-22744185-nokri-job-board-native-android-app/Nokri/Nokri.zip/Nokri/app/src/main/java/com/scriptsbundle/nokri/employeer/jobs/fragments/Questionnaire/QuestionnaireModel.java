package com.scriptsbundle.nokri.employeer.jobs.fragments.Questionnaire;

public class QuestionnaireModel {
    public String isShowQuestionnaireSection;
    public String questionsLabel;
    public String questionsPlaceholder;
    public String heading;
    public String question;
    public String answer;
    public String buttonYes;
    public String buttonNo;
}
