package com.scriptsbundle.nokri.employeer.jobs.models;

public class AttachmentModel {
    public String attachmentId;
    public String url;
    public String type;

}
