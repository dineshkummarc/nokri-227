package com.scriptsbundle.nokri.RichEditor.styles;

import com.scriptsbundle.nokri.RichEditor.spans.AreImageSpan;

public interface IARE_Image {

    public void insertImage(final Object src, final AreImageSpan.ImageType type);
}
