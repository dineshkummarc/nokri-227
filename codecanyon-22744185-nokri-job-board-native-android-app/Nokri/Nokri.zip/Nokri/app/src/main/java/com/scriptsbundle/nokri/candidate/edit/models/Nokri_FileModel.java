package com.scriptsbundle.nokri.candidate.edit.models;

/**
 * Created by Glixen Technologies on 25/01/2018.
 */

public class Nokri_FileModel {

    private String id;
    private String name;
    private String url;
    private String buttonText;

    public String getButtonText() {
        return buttonText;
    }

    public void setButtonText(String buttonText) {
        this.buttonText = buttonText;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
