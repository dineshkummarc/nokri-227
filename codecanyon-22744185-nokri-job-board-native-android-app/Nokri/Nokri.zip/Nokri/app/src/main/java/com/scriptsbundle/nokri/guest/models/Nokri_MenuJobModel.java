package com.scriptsbundle.nokri.guest.models;

public class Nokri_MenuJobModel {
    private String viewJob;
    private String viewCompanyProfile;

    public String getViewJob() {
        return viewJob;
    }

    public void setViewJob(String viewJob) {
        this.viewJob = viewJob;
    }

    public String getViewCompanyProfile() {
        return viewCompanyProfile;
    }

    public void setViewCompanyProfile(String viewCompanyProfile) {
        this.viewCompanyProfile = viewCompanyProfile;
    }
}
