package com.scriptsbundle.nokri.guest.faq.models;

/**
 * Created by Glixen Technologies on 09/01/2018.
 */

public class Child {
    private String childText;

    public Child(String childText) {
        this.childText = childText;
    }

    public String getChildText() {
        return childText;
    }

    public void setChildText(String childText) {
        this.childText = childText;
    }
}
