package com.scriptsbundle.nokri.candidate.profile.model;

/**
 * Created by Glixen Technologies on 17/01/2018.
 */

public class Nokri_PortfolioModel {

    private String id;
    private String url;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
