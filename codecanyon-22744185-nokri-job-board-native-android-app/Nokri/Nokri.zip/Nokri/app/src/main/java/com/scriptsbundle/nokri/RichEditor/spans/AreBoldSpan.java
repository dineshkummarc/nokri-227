package com.scriptsbundle.nokri.RichEditor.spans;

import android.graphics.Typeface;
import android.text.style.StyleSpan;

/**
 * Created by wliu on 2018/1/19.
 */

public class AreBoldSpan extends StyleSpan {

    public AreBoldSpan() {
        super(Typeface.BOLD);
    }
}
