package com.scriptsbundle.nokri.activities.WPML;

import java.util.ArrayList;

public class WPMLModel {
    public String wpmlLogo;
    public String header1;
    public String header2;
    public String languageDescription;
    public String skipText;
    public String submit;
    public boolean isActive;
    public ArrayList<LangArray> langArray = new ArrayList<>();




}

