package com.scriptsbundle.nokri.candidate.profile.model;

public class Nokri_ProgressModel {
    int progress;
    String title;

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
