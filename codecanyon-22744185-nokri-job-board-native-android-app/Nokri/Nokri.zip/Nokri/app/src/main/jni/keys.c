#include <jni.h>
JNIEXPORT jstring JNICALL
Java_com_scriptsbundle_nokri_NokriApplication_placeInitialize(JNIEnv *env, jobject instance) {
    return (*env)-> NewStringUTF(env, "AIzaSyD-J2TEiz_qEXz3dFpfkN7UTZ9AjFeRij0");
}
JNIEXPORT jstring JNICALL
Java_com_scriptsbundle_nokri_activities_NokriSplashActivity_placeInitialize(JNIEnv *env, jobject instance) {
    return (*env)-> NewStringUTF(env, "AIzaSyD-J2TEiz_qEXz3dFpfkN7UTZ9AjFeRij0");
}
JNIEXPORT jstring JNICALL
Java_com_scriptsbundle_nokri_employeer_dashboard_fragments_NokriEmployeerDashboardFragment_placeInitialize(JNIEnv *env, jobject instance) {
    return (*env)-> NewStringUTF(env, "AIzaSyD-J2TEiz_qEXz3dFpfkN7UTZ9AjFeRij0");
}
JNIEXPORT jstring JNICALL
Java_com_scriptsbundle_nokri_employeer_jobs_fragments_NokriPublicProfileFragment_placeInitialize(JNIEnv *env, jobject instance) {
    return (*env)-> NewStringUTF(env, "AIzaSyD-J2TEiz_qEXz3dFpfkN7UTZ9AjFeRij0");
}
JNIEXPORT jstring JNICALL
Java_com_scriptsbundle_nokri_Video_YoutubeActivity_placeInitialize(JNIEnv *env, jobject instance) {
    return (*env)-> NewStringUTF(env, "AIzaSyD-J2TEiz_qEXz3dFpfkN7UTZ9AjFeRij0");
}